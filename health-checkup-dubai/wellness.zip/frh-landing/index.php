<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <!-- Google Tag Manager -->
  <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
    new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
  j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
  'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WRDM7MV');</script>
<!-- End Google Tag Manager -->

<meta name="robots" content="noindex">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="title" content="First Response Healthcare">
<meta name="language" content="Arabic">
<meta http-equiv="content-type" content="text/html; charset=utf-8"/>
<title>First Response Healthcare</title>
<link href="images/favicon.png" rel="icon" sizes="32x32"/>
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
<!-- <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
--><!-- <link rel="stylesheet" type="text/css" href="intl-tel-input/css/intlTelInput.css"> -->
<link href="css/animate.css" rel="stylesheet" type="text/css">
<!--<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.12/jquery.bxslider.css"/>-->
<link href="css/style-26.css" rel="stylesheet" type="text/css"/>

<!--slider-->

<!--<link rel="stylesheet" href="js/assets/owl.carousel.min.css">-->
<!--<link rel="stylesheet" href="js/assets/owl.theme.default.min.css">-->

<script src="js/jquery-1.11.1.min.js"></script>
<!-- <link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> 
  <script src="js/bootstrap.min.js"></script>-->
  <!--<script src="js/jquery.bxslider.js"></script>-->
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
  integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous"> 

  <!--slider-->
  <link rel="stylesheet" href="css/bootstrap-3.3.5.min.css" id="bootstrap-css"> 
  <link rel="stylesheet" href="css/swiper.min.css"> 

  <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap-theme.min.css"> -->
  <link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css" />
  <!-- <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap-glyphicons.css"> -->
  <script src="js/moment.min.js"></script>
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>-->
  <script src="js/bootstrap.min.js"></script> 

  <script src="js/bootstrap-datetimepicker.min.js"></script>



  <style type="text/css">
    #gif {
      display: none;
      background-color: #fff;
      position: fixed;
      top: calc(50% - 124px);
      left: calc(50% - 124px);
    }
    #back-gif {
      display: none;
      background-color: #fff;
      opacity: .8;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      z-index: 999999;
    }
    body {
      background-color: #f9f9f8;
    }

    .bg-red{
      background-color: #c9252b;
    }
    .bg-white{
      background-color: #fff
    }
    .btn-white, .btn-white:hover{
      background-color: #fff;
      color: #c9252b;
      padding: 10px;
      border: 0;
      border-radius: 7px;
    }
    .btn-red{
      background-color: #c9252b;
      color: #fff;
      padding: 10px;
      border: 0;
      border-radius: 7px;
    }

    .text-white{
      color: #fff;
    }
    .text-red{
      color: #c9252b;
    }

    .bg-clients{
      background-image: linear-gradient(rgba(255,255,255,0.9),rgba(255,255,255,0.8)),url('../images/happy-clients.jpg');
      background-size: cover;
      background-attachment: fixed;
      background-position: top right;
    }

    .swiper-slide::before{
      position: absolute!important;
      bottom: -7px!important;
      left: 35px!important;
      display: block!important;
      width: 14px!important;
      height: 14px!important;
      border: 1px solid #ededed!important;
      border-top: none!important;
      border-left: none!important;
      background-color: #fafafa!important;
      content: ""!important;
      -webkit-transform: rotate(45deg)!important;
      -ms-transform: rotate(45deg)!important;
      transform: rotate(45deg)!important;
    }

    .swiper-slide p::before{
      bottom: 47px!important;
      box-sizing: border-box!important;
      color: #bbb!important;
      content: '\201C'!important;
      display: block!important;
      height: 96px!important;
      left: 55px!important;
      position: absolute!important;
      right: 515.391px!important;
      text-size-adjust: 100%!important;
      top: 25px!important;
      width: 24.6094px!important;
      column-rule-color: #bbb!important;
      perspective-origin: 12.2969px 48px!important;
      transform-origin: 12.2969px 48px!important;
      border: 0 none #bbb!important;
      font: normal normal normal normal 60px / 96px Georgia,serif!important;
      margin: -25px 0 0 -40px!important;
      outline: #bbb none 0!important;
    }

    .feedback{
      margin: 2px!important;
      color: #777!important;
      font-size: 18px!important;
      border: 1px solid #ededed!important;
      background-color: #fafafa!important;
      border-radius: 4px!important;
      padding: 20px 40px;
    }

    .feedback-user{
      padding: 20px 40px;
    }

    .feedback-user img{
      width: 50px!important;
      height: 50px!important;
    }

    .user-pic, .user-pic img, .user-info, .user-info p{
      display: inline;
    }

    .input-group-text, .form-control {
      background-color: #fff;
      border-right: 0px;
      border-left: 0px;
      border-top: 0px;
      border-radius: 0px;
      background-color: transparent;
    } 


    .submit-btn{
      background-color: #c9252b;
      border: 0px;
      color: #fff;
      padding: 14px 40px 11px;
      border-radius: 28px;
      margin: 2em 0;
      float: left;
    }

    select.goog-te-combo{
      background-color: #fff;
      border: 1px solid #c9252b;
      padding: 10px;
      border-radius: 25px;
    }

    .telephone a, .telephone a:hover{
      background-color: #c9252b;
      color: #fff;
      padding: 15px 30px;
      border-radius: 28px;
      text-decoration: none;
    }

    .logo{
      max-width: 180px;
    }
    .accordion1 .card-header:after {
      font-family: 'Font Awesome 5 Free';  
      content: "\f068";
      float: right; 
    }
    .accordion1 .card-header.collapsed:after {
      /* symbol for "collapsed" panels */
      font-family: 'Font Awesome 5 Free';  
      content: "\f067"; 
    }
    ul.checklist{
      list-style-image: url('../images/triangle-right-arrow.png');
    }

    ul.checklist li {
      padding-left: 10px;
    }
    .contact-form-border{
      border: 5px solid #e4e4e4;
    }
    form label{
      color: red;
      left: 0;
    }
    .footer-bg{
      background-color: #222222;
      color: #808080;
    }
    .footer-bg a, .footer-bg a:hover, .footer-bg li a, .footer-bg li a:hover{
      color: #808080;
      text-decoration: none;
    }
    .card-header{
      background-color: #f9f9f8;
    }
    .titles-spacing{
      padding-top: 65px;
      padding-bottom: 65px;
    }
    .main-body{
      margin-top: 8rem;
    }
    .home-bg{
      margin-top: 2rem;
      height: 80vh;
      background-image: url(../images/Banner.jpg);
      background-size: 100% 100%;
    }

    .home-banner-form{
      margin-top: 10em;
      background-color: rgba(255,255,255,0.6);
      padding: 30px 40px;
    }
    .health-screening{
      margin-top: 3em;
    }
    .health-screening-content{
      padding-top: 2em;
    }
  </style>

</head>

<body class="site com-sppagebuilder view-page no-layout no-task itemid-437 en-gb ltr  sticky-header layout-fluid">
  <!-- Google Tag Manager (noscript) -->
  <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-WRDM7MV"
    height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->


    <div class="body-innerwrapper">

      <header class="maih-head">
        <div class="container">
          <div class="row">
            <div class="col-md-4">
              <a href="index.html"><img src="images/logo.png" alt="mindset Logo" class="logo"></a>
            </div>
            <div class="col-md-3"></div>
            <div class="col-md-2 btn-left top-bar" style="direction: ltr;">
              <a href="tel:0 50 50 50 387" target="_blank" ><div class="top-bar-inner"><div class="top-bar-innermost"><i class="fa fa-phone"></i> 050 50 50 387</div></div></a>
            </div>
            <div class="col-md-3 btn-right top-bar">
              <div id="google_translate_element"></div>
            </div>
          </div>
        </div>
      </header>

      <section class="featured">
        <div class="top-banner">
          <img class="d-banner" src="images/Banner.jpg" style="width: 100%;" />
          <img class="m-banner" src="images/m-Banner.jpg" style="width: 100%;" />
        </div>
        <div class="form-container">
          <form role="form" name="query_form" id="query_form" action="thank-you.php" method="post"
          onsubmit="return save_landing_pageinfo('query_form');" novalidate="novalidate">
          <div class="form-title h4 text-center">
            <span class="formhead">Enquire Now</span><br>
            <!-- <small><span class="formspan">Our Admission Counsellors Are Here To Help</span></small> -->
          </div>
          <div class="row">
            <div class="col-sm-12">                
              <input type="text" class="form-control" placeholder="Your Name" name="fname"
              id="first_name">             
            </div>
            <div class="col-sm-12">
              <input type="text" class="form-control" placeholder="Your Email" name="email"
              id="emailid">
            </div>  
            <div class="col-sm-12">
              <input type="text" class="form-control" placeholder="Phone Number"
              name="mobile" id="mobile" maxlength="10">
            </div>
            <div class="col-sm-12">
              <input type="text" class="form-control" placeholder="Your Message"  name="comment"
              id="comment">
            </div>  
            <!--<div class="col-sm-6">-->
            <!--  <input type="text" id="date" name="date" class="form-control" placeholder="Date">-->
            <!--</div>-->
            <!--<div class="col-sm-6">-->
            <!--  <input type="text" id="time" name="time" class="form-control" placeholder="HH:MM">-->
            <!--</div> -->
            <div class="col-xs-12" style="text-align: center;">
              <input type="submit" value="Submit">
              <span class="ajax-loader"></span>
              <input type="hidden" name="source" value="query_form"/>
              <input type="hidden" id="course-name" name="course-name" value="Generic">
            </div>
          </div>
        </form>
      </div>
    </section>

    
    <section>
      <div class="container health-screening">
        <div class="row bg-red text-white">
          <div class="col-sm-8 text-center health-screening-content">
            <h3 class="text-uppercase">HEALTH SCREENING - GENERAL HEALTH CHECK</h3>
            <p class="font-weight-bold">Prevention is better than cure!</p>
            <p>Check your health status with a general health check every 6-12 months even if you feel healthy. A preventive health check is a combination of different lab tests used to evaluate your overall health and detect a wide range of disorders, including anemia, leukemia and infections.</p>
            <button class="btn-primary text-capitalize btn-white"  data-toggle="modal" data-target="#iaminterested">Request an appointment</button>
          </div>
          <div class="col-sm-4 bg-white pr-sm-0 ">
           <img class="w-100 img-fluid" src="images/1.jpg" alt="" />
         </div>
       </div>
     </div>
   </section>


   <section>
     <div class="container">
       <div class="row">
         <div class="col-md-12 text-center titles-spacing">
           <p class="text-red">Fast &amp; Reliable Test</p>
           <h1>Health Check - How to!</h1>
         </div>
       </div>
       <div class="row">
         <div class="col-md-6">
          <div class="panel-group" id="accordion">
            <div class="panel panel-default">
              <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">Collapsible Group 1</a>
                </h4>
              </div>
              <div id="collapse1" class="panel-collapse collapse in">
                <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                  sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                  quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                </div>
              </div>
              <div class="panel panel-default">
                <div class="panel-heading">
                  <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">Collapsible Group 2</a>
                  </h4>
                </div>
                <div id="collapse2" class="panel-collapse collapse">
                  <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                  </div>
                </div>
                <div class="panel panel-default">
                  <div class="panel-heading">
                    <h4 class="panel-title">
                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Collapsible Group 3</a>
                    </h4>
                  </div>
                  <div id="collapse3" class="panel-collapse collapse">
                    <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                      sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                      quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                    </div>
                  </div>
                </div> 
                <div class="text-center">
                  <button class="btn btn-red text-capitalize mt-5"  data-toggle="modal" data-target="#iaminterested">Request an appointment</button>
                </div>
              </div>
              <div class="col-md-6 shadow-lg bg-white">
                <p class="text-red">Self-assessment checklist</p>
                <h1>A Quick Checklist for You!</h1>
                <p>Adults and children should check their health status every year. If you answer any of the questions below with YES, you should do a preventive health checkup on a regular basis.</p>
                <ul class="checklist">
                  <li>Do you eat an unhealthy diet?</li>
                  <li>Are you overweight?</li>
                  <li>Do you sleep too little or is your sleep quality poor?</li>
                  <li>Do you have high-stress levels?</li>
                  <li>Do you exercise little or not at all?</li>
                  <li>Do you have family history of heart diseases, high blood pressure, diabetes or other diseases?</li>
                  <li>Do you smoke or drink alcohol on a regular basis?</li>
                  <li>...and more!</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        
        <section>
          <div class="bg-clients">
            <div class="container">
              <div class="row">
                <div class="col-md-12 titles-spacing">
                  <p class="text-red">Personalized Nutrition Consultation.</p>
                  <h1>Happy Clients - Real Success.</h1>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <iframe style="width: 100%; height: 315px;" src="https://www.youtube.com/embed/vC6b8kLpUXc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div class="col-md-6">
                  <iframe style="width: 100%; height: 315px;" src="https://www.youtube.com/embed/vC6b8kLpUXc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 text-center">
                  <button class="btn btn-primary text-capitalize btn-red" data-toggle="modal" data-target="#iaminterested"> Book Now!</button>
                </div>
              </div>
              <div class="row">
                <!-- Swiper -->
                <div class="swiper-container">
                  <div class="swiper-wrapper testimonials">
                    <div class="swiper-slide ">
                      <div class="feedback">
                       <p><span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                        <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                        <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                        <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                        <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                        Having had to have medical care around the country, this place showed me that it can be done well.</p>              
                      </div>
                      <div class="feedback-user">
                        <div class="user-pic">
                          <img src="images/photo.jpg" alt="" />
                        </div>
                        <div class="user-info">
                          <p class="font-weight-bold">Eric Smith
                            4 months ago</p>
                          </div>
                        </div>
                      </div>
                      <div class="swiper-slide">
                        <div class="feedback">
                         <p><span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                          <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                          <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                          <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                          <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                          Having had to have medical care around the country, this place showed me that it can be done well.</p>
                        </div>
                        <div class="feedback-user">
                          <div class="user-pic">
                            <img src="images/photo.jpg" alt="" />
                          </div>
                          <div class="user-info">
                            <p class="font-weight-bold">Eric Smith
                              4 months ago</p>
                            </div>
                          </div>
                        </div>
                        <div class="swiper-slide">
                          <div class="feedback">
                           <p><span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                            <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                            <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                            <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                            <span class="wp-star"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="17" height="17" viewBox="0 0 1792 1792"><path d="M1728 647q0 22-26 48l-363 354 86 500q1 7 1 20 0 21-10.5 35.5t-30.5 14.5q-19 0-40-12l-449-236-449 236q-22 12-40 12-21 0-31.5-14.5t-10.5-35.5q0-6 2-20l86-500-364-354q-25-27-25-48 0-37 56-46l502-73 225-455q19-41 49-41t49 41l225 455 502 73q56 9 56 46z" fill="#e7711b"></path></svg></span>
                            Having had to have medical care around the country, this place showed me that it can be done well.</p>
                          </div>
                          <div class="feedback-user">
                            <div class="user-pic">
                              <img src="images/photo.jpg" alt="" />
                            </div>
                            <div class="user-info">
                              <p class="font-weight-bold">Eric Smith
                                4 months ago</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        <!-- Add Pagination -->
                        <!--  <div class="swiper-pagination"></div> -->
                      </div>
                    </div>
                  </div>
                </div>
              </section>


              <section>
                <div class="container">
                  <div class="row">
                    <div class="col-md-12 text-center titles-spacing">
                      <h1>Our Dietitians & Nutritionists</h1>
                      <p>Our team is specialized in Diet Plans, Nutrition Consultation and Meal Plans!</p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 px-0">
                      <img class="w-100" src="images/Katharina_Elbracht.png">
                    </div>
                    <div class="col-md-6 px-0">
                      <img class="w-100" src="images/Katharina_Elbracht.png">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 px-0">
                      <img class="w-100" src="images/Katharina_Elbracht.png">
                    </div>
                    <div class="col-md-6 px-0">
                      <img class="w-100" src="images/Katharina_Elbracht.png">
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6 px-0">
                      <img class="w-100" src="images/Katharina_Elbracht.png">
                    </div>
                  </div>
                </div>
              </section>


              <section>
                <div class="contact container contact-form-border">
                  <div class="row">
                    <div class="col-md-10 col-md-offset-1 px-0">
                      <h1>Contact Us</h1>
                      <p>You have questions or want to make an appointment with our therapists? Reach out to us now!</p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-10 col-md-offset-1">
                      <form role="form" name="contact_form" id="contact_form" action="thank-you.php" method="post"
                      onsubmit="return save_landing_pageinfo('contact_form');" novalidate="novalidate">
                      <div class="row">
                        <div class="col-md-12 fields-bottom-border">
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" placeholder="Your Name" name="fname"
                            id="first_name">
                          </div>                          
                        </div>
                        <div class="col-md-12 fields-bottom-border">
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" placeholder="Your Email" name="email"
                            id="emailid">
                          </div>                          
                        </div>  
                        <div class="col-md-12 fields-bottom-border">
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-mobile" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" placeholder="Phone Number"
                            name="mobile" id="mobile" maxlength="10">
                          </div>                          
                        </div>
                        <div class="col-md-12 fields-bottom-border">
                          <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-comments-o" aria-hidden="true"></i></span>
                            <input type="text" class="form-control" placeholder="Your Message"  name="comment"
                            id="comment">
                          </div>                               
                        </div>  
                        <!--<div class="col-sm-6">-->
                        <!--  <input type="text" id="date" name="date" class="form-control" placeholder="Date">-->
                        <!--</div>-->
                        <!--<div class="col-sm-6">-->
                        <!--  <input type="text" id="time" name="time" class="form-control" placeholder="HH:MM">-->
                        <!--</div> -->
                        <div class="col-xs-12" style="text-align: center;">
                          <input type="submit" class="submit-btn" value="Submit">
                          <span class="ajax-loader"></span>
                          <input type="hidden" name="source" value="contact_form"/>
                          <input type="hidden" id="course-name" name="course-name" value="Generic">
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </section>




            <footer style="width: 100%; float: left;">
              <div class="container">
                <div class="row">

                  <div class="disclaimer-main">
                    <p><i class="fa fa-map-marker footer-icon" aria-hidden="true"></i> P.O. Box 117341
                      <a href="mailto:info@firstresponse.ae" target="_blank"> <i class="fa fa-envelope footer-icon" aria-hidden="true"></i> info@firstresponse.ae </a> <a href="tel:0 50 50 50 387" target="_blank"><i class="fa fa-phone footer-icon" aria-hidden="true"></i> 0 50 50 50 387</a></p>
                      <p style="font-weight: 700;">Copyright © 2018 First Response Healthcare
                        <br>
                        All rights reserved. Ministry of Health License No: PE14910-21/09/2019
                      </p>
                    </div>
                  </div>
                </div>
              </footer>


              <button id="desktop" type="submit" class="request-brouchuer hidden-xs hidden-sm" data-toggle="modal" data-target="#iaminterested"><i class="fa fa-phone"></i>Call Now
              </button>
              <!-- <a href="javascript:void(0)" class="desktop1">Give Missed Call for an Exclusive<br>Counselling Session in India<br><span><strong>+91-9021103676</strong></span></a> -->
              <button id="mobile1" type="submit" class="btn request-brouchuer hidden-lg hidden-md mobile-btn" data-toggle="modal"
              data-target="#iaminterested"><i
              class="fa fa-phone"></i>
            </button>


          </div>



          <!-- About Us Modal -->
          <div class="modal fade" id="aboutusModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                  </button>
                  <h4 class="modal-title" id="myModalLabel">About Us</h4>
                </div>
                <div class="modal-body" id="contact-popup">
                  <p>Mindset enables US universities to extend their online offerings globally.</p><br>
                  <p><strong>OUR OFFICES:</strong></p>
                  <p style="color: #a41c36;"><strong>USA</strong></p>
                  <p><strong>Mindset Global Education</strong></p>
                  <p>321 Walnut street #421<br>
                    Newton, MA 02465<br>
                    Phone: +1 617 862 1626</p><br>

                    <p style="color: #a41c36;"><strong>INDIA</strong></p>
                    <p><strong>India  Admission Assistance office</strong><br>
                      Strategic Alliances Network <br>
                      Level 3 Citi Tower, <br>
                      Parel, Mumbai 400012.<br>
                      Phone: +91 9820294371<br></p><br>
                      <p style="color: #a41c36;">Email:info@mindset.global</p>
                    </div>
                  </div>
                </div>
              </div>

              <!-- Modal -->
              <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                <div class="modal-dialog" role="document">
                  <div class="modal-content">
                    <div class="modal-header">
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                      </button>
                      <h4 class="modal-title" id="myModalLabel">كن على تواصل مع طبيبك الأن</h4>
                    </div>
                    <div class="modal-body">
                      <!--<p class="popform-txt">-->
                      <!--  Talk To Our Admission Counsellors to<br>-->
                      <!--  Find The Best Course For You-->
                      <!--</p>-->

                      <form role="form" name="counsellers" id="counsellers" action="thank-you.php" method="post"
                      onsubmit="return save_landing_pageinfo('counsellers');" novalidate="novalidate">
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="ادخل إسمك " name="fname">
                      </div>
                      <div class="form-group">
                        <input type="email" class="form-control" placeholder="أدخل الإميل" name="email">
                      </div>
                      <div class="form-group">
                        <input type="number" class="form-control" placeholder="أدخل رقم هاتفك " name="mobile">
                      </div>
                      <div class="form-group">
                        <input type="text" class="form-control" placeholder="أضف تعليقك " name="comment">
                      </div>
                      <!--<div class="checkbox">-->
                      <!--  <label style="font-size:13px;">-->
                      <!--    <input type="checkbox" checked="" style="width:15px;height:15px;"> I grant Mindset Global-->
                      <!--    permission to contact me.-->
                      <!--  </label>-->
                      <!--</div>-->
                      <button type="submit" class="btn btn-default pop-btn">أرسل</button>
                      <input type="hidden" name="source" value="counsellers"/>
                      <input type="hidden" id="course-name" name="course-name" value="">

                    </form>


                  </div>

                </div>
              </div>
            </div>


            <!-- Modal -->
            <div class="modal fade" id="iaminterested" tabindex="-1" role="dialog" aria-labelledby="iaminterestedLabel">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title" id="iaminterestedLabel">I am Interested!</h4>
                  </div>
                  <div class="modal-body">
              <!-- <p class="popform-txt">
          BOOK AN APPOINTMENT
        </p> -->

        <form role="form" name="mainpopup" id="mainpopup" action="thank-you.php" method="post"
        onsubmit="return save_landing_pageinfo('mainpopup');" novalidate="novalidate">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Your Name" name="fname">
        </div>
        <div class="form-group">
          <input type="email" class="form-control" placeholder="Your Email" name="email">
        </div>
        <div class="form-group">
          <input type="number" class="form-control" placeholder="Phone Number" name="mobile"  maxlength="10">
          <input type="hidden" name="source" value="main-popup"/>
        </div>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Your Message" name="comment">
        </div>
        

        <button type="submit" class="btn btn-default pop-btn">Submit</button>
        <input type="hidden" name="source" value="mainpopup"/>
        <input type="hidden" id="course-name" name="course-name" value="Generic">
      </form>


    </div>

  </div>
</div>
</div>


<!-- Main Modal -->
<div class="modal fade" id="main-pop" tabindex="-1" role="dialog" aria-labelledby="main-popLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
        </button>
        <h4 class="modal-title" id="main-popLabel">Enquire Now!</h4>
      </div>
      <div class="modal-body">
     <!-- <p class="popform-txt">
      BOOK AN APPOINTMENT
    </p> -->

    <form role="form" name="mainpopup" id="mainpopup" action="thank-you.php" method="post"
    onsubmit="return save_landing_pageinfo('mainpopup');" novalidate="novalidate">
    <div class="form-group">
      <input type="text" class="form-control" placeholder="Your Name " name="fname">
    </div>
    <div class="form-group">
      <input type="email" class="form-control" placeholder="Your Email" name="email">
    </div>
    <div class="form-group">
      <input type="number" class="form-control" placeholder="Phone Number" name="mobile"  maxlength="10">
      <input type="hidden" name="source" value="main-popup"/>
    </div>
    <div class="col-sm-6">
      <input type="text" id="date2" name="date2" class="form-control" placeholder="Date">
    </div>
    <div class="col-sm-6">
      <input type="text" id="time2" name="time2" class="form-control" placeholder="HH:MM">
    </div>
  <!--<div class="form-group">
      <input type="text" class="form-control" placeholder="HH:MM" name="time" id="time">
    </div>
   <div class="checkbox">
      <label style="font-size:13px;">
       <input type="checkbox" checked="" style="width:15px;height:15px;"> I grant Mindset Global
       permission to contact me.
   </label>
 </div> -->

 <button type="submit" class="btn btn-default pop-btn">أرسل</button>
 <input type="hidden" name="source" value="mainpopup"/>
 <input type="hidden" id="course-name" name="course-name" value="Generic">
</form>


</div>

</div>
</div>
</div>

<div id="back-gif">
 <div id="gif">
   <img src="images/frh-loader.gif" style="max-width: 250px;" alt="Please Wait. We are Submitting Your Enquiry.">
 </div>
</div>


<script src="js/owl.carousel.min.js"></script>
<script src="js/jquery.validate.js"></script>
<script src="js/mobilevalidate-4.js"></script>
<script src="js/cookie.js"></script>
<script src="js/popout-1.js"></script>
<script type="text/javascript" src="http://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<script type="text/javascript">
  function googleTranslateElementInit() {
    new google.translate.TranslateElement({pageLanguage: 'ar'}, 'google_translate_element');
  }
</script>
<script>
// $(document).ready(function() {

//   $('.modal').on('shown.bs.modal', function () {
//   $('#date1').datetimepicker({
//  minDate:new Date(),
//  format: "DD/MM/YYYY"
//   });
//   $('#time1').datetimepicker({  
//          minDate:new Date(),
//     format: 'LT'
//   });
// });

//   $(function() {
//  $('#date').datetimepicker({
//    minDate:new Date(),  
//     format: "DD/MM/YYYY"
//    });
//     $('#time').datetimepicker({  
//          minDate:new Date(),
//       format: 'LT'
//    });
//   });
// });
</script>

<script>
  function mailsendvaithemes(elm) {


    if (elm == "core") {
            // alert("1");
            document.getElementById("course-name").value = "core";
          }

          if (elm == "becomemanager") {
            // alert("2");
            document.getElementById("course-name").value = "becomemanager";
            
          }

          if (elm == "businessanalyst") {
            // alert("3");
            document.getElementById("course-name").value = "businessanalyst";
            
          }

          if (elm == "economicsmanager") {
            // alert("4");
            document.getElementById("course-name").value = "economicsmanager";

          }

          if (elm == "entrepreneurshipessentials") {
            // alert("5");
            document.getElementById("course-name").value = "entrepreneurshipessentials";
            
          }

          if (elm == "financialaccounting") {
            // alert("6");
            document.getElementById("course-name").value = "financialaccounting";
            
          }

          if (elm == "leadigfinance") {
            // alert("7");
            document.getElementById("course-name").value = "leadigfinance";
            
          }

          if (elm == "negotiationmastery") {
            // alert("8");
            document.getElementById("course-name").value = "negotiationmastery";
            
          }

          if (elm == "sustainablebusinessstrategy") {
            // alert("9");
            document.getElementById("course-name").value = "sustainablebusinessstrategy";
            
          }


        }
      </script>
      <script>
        $('.owl-carousel').owlCarousel({
          loop: true,
          margin: 10,
          responsiveClass: true,
          autoplay: true,
          autoplayTimeout: 3000,
          autoplayHoverPause: true,
          nav: false,
          responsive: {
            0: {
              items: 1
            },
            600: {
              items: 2
            },
            1000: {
              items: 4
            }
          }
        })
      </script>


      <script>
    // When the user scrolls down 150px from the top of the document, show the button
    window.onscroll = function () {
      scrollFunction()
    };

    function scrollFunction() {
      if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
        document.getElementById("mobile1").style.display = "block";
        document.getElementById("desktop").style.display = "block";
      } else {
        document.getElementById("mobile1").style.display = "none";
        document.getElementById("desktop").style.display = "none";
      }
    }

    $(window).scroll(function() {
      if ($(this).scrollTop() > 300){  
        $('.desktop1').css("display","block");
      }
      else{
        $('.desktop1').css("display","none")
      }
    });

  </script>

  <script>
    $(window).scroll(function () {
      var scroll = $(window).scrollTop();

      if (scroll >= 75) {
        $(".maih-head").addClass("darkHeader");
      } else {
        $(".maih-head").removeClass("darkHeader");
      }
    });

  </script>

  <script type="text/javascript">
    var _paq = _paq || [];
    /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
    _paq.push(['trackPageView']);
    _paq.push(['enableLinkTracking']);
    (function() {
      var u="//pw1.logicloop.io/";
      _paq.push(['setTrackerUrl', u+'piwik.php']);
      _paq.push(['setSiteId', '60']);
      var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
      g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
    })();
  </script>

  <script>
    var url_string = window.location.href; //window.location.href
    var url = new URL(url_string);
    var c = url.searchParams.get("cstm_ppc_channel");
    //console.log(c);
    //alert(c);
    function save_landing_pageinfo(elm) {

      var name = jQuery('#' + elm + ' input[name="fname"]').val();
      var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
      var emailid = jQuery('#' + elm + ' input[name="email"]').val();


      if (name == "") {
        name = 'no name';
      }

      if (emailid == '') {

        $('#emailid').focus();
        return false;

      }

      if (mobileno.length != '10') {

        $('#mobileno').focus();
        return false;

      }
      $('#back-gif').show();
      $('#gif').show();

      if (name != "" && emailid != "" && mobileno != "") {
        var tags = document.getElementById("course-name").value;
        var tags_withchannel = document.getElementById("course-name").value+"_"+c;
        var webToLeadData = {
         'firstname': name,
         'email': emailid,
         'mobile': mobileno,
         'tags': tags_withchannel,
                // 'cstm_source_website': 'kamanewalaghar'
              };

            //            console.log(webToLeadData);
            MTI.webToLead(webToLeadData,
              function () {

                submitForm(elm);

              },
              function () {
                console.log("There was an error saving the lead to the marketing automation system. ");
                submitForm(elm);
              }
              );
          }
          return false;
        }

    function submitForm(elm) { // submits form
        //document.getElementById(elm).submit();
        document.createElement('form').submit.call(document.getElementById(elm));
      }
    </script>
    <script src="https://frh.logicloop.io/mtcwtl.js"></script>
    <!-- LL CRM -->
<!-- <script>
    (function(w,d,t,u,n,a,m){w['MauticTrackingObject']=n;
        w[n]=w[n]||function(){(w[n].q=w[n].q||[]).push(arguments)},a=d.createElement(t),
        m=d.getElementsByTagName(t)[0];a.async=1;a.src=u;m.parentNode.insertBefore(a,m)
    })(window,document,'script','http://hbx1.logicloop.io/mtc.js','mt');

    mt('send', 'pageview');
  </script> -->
  <!-- LL CRM -->

  <!--<script>-->
  <!--function save_landing_pageinfo(elm) {-->
  <!--document.createElement('form').submit.call(document.getElementById(elm));-->
  <!--}-->

  <!--</script>-->
  <!-- Swiper JS -->
  <script src="js/swiper.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper('.swiper-container', {
      slidesPerView: 3,
      spaceBetween:40,
      freeMode: true,
      navigation: {
       nextEl: '.outer-right',
       prevEl: '.outer-left',
     },
     pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
    loop: true,
    autoplay: {
      delay: 4000,
    },
  });
</script>
</body>
</html>
